"""Run real HDDM models on validated data; one Slurm job can fit four chains."""
from __future__ import annotations

import argparse
import json
import os
import tempfile
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

from .models import ROOT, build_hddm_model, check_input, load_models


def fit_chain(data, spec, output: Path, chain: int, samples: int,
              burn: int, seed: int) -> str:
    """Fit one actual HDDM chain and save its model and sampler database."""
    import hddm

    np.random.seed(seed + chain)
    model = build_hddm_model(data, spec, hddm_module=hddm)
    model.find_starting_values()
    database = output / f"chain_{chain}_db"
    print(f"START chain {chain}: {samples} iterations, burn-in {burn}", flush=True)
    model.sample(samples, burn=burn, dbname=str(database), db="pickle")
    model_path = output / f"chain_{chain}.hddm"
    model.save(str(model_path))
    print(f"SAVED chain {chain}: {model_path}", flush=True)
    return str(model_path)


def run_fit(study: str, model_name: str, *, chains: int, workers: int,
            samples: int, burn: int, seed: int, smoke: bool = False) -> None:
    if chains < 1 or workers < 1 or samples <= burn or burn < 0:
        raise ValueError("Require positive chains/workers and 0 <= burn < samples")
    spec = load_models()[model_name]
    data, audit = check_input(study, spec)
    print(f"STUDY {study} | MODEL {model_name} | TRIALS {len(data)}", flush=True)
    print(f"DRIFT {spec.drift_formula} | PARAMETERS {spec.include}", flush=True)

    base = ROOT / "studies" / study / "results" / "fits" / model_name
    if smoke:
        # Uses real data, actual HDDM likelihood, sampler, model.save and hddm.load.
        import hddm
        with tempfile.TemporaryDirectory(prefix="esaddm_smoke_") as temp:
            path = fit_chain(data, spec, Path(temp), 1, samples, burn, seed)
            reloaded = hddm.load(path)
            if reloaded is None:
                raise RuntimeError("HDDM returned no model after reload")
        print("PASS actual HDDM fit/save/reload on the full prepared dataset", flush=True)
        return

    if base.exists() and any(base.iterdir()):
        raise FileExistsError(f"Fit folder is not empty; refusing overwrite: {base}")
    base.mkdir(parents=True, exist_ok=True)
    record = {
        "study": study, "model": model_name, "formula": spec.drift_formula,
        "coordinate": spec.coordinate, "included_ddm_parameters": spec.include,
        "participants": audit["participants"], "trials": audit["rows"],
        "chains": chains, "samples_per_chain": samples, "burn_per_chain": burn,
        "retained_per_chain": samples - burn,
        "seeds": [seed + c for c in range(1, chains + 1)],
        "slurm_job_id": os.environ.get("SLURM_JOB_ID"),
        "started_utc": datetime.now(timezone.utc).isoformat(),
    }
    (base / "run.json").write_text(json.dumps(record, indent=2) + "\n")
    if workers == 1:
        for chain in range(1, chains + 1):
            fit_chain(data, spec, base, chain, samples, burn, seed)
    else:
        from joblib import Parallel, delayed
        Parallel(n_jobs=min(workers, chains), backend="loky")(
            delayed(fit_chain)(data, spec, base, chain, samples, burn, seed)
            for chain in range(1, chains + 1)
        )
    print(f"PASS {study}/{model_name}: {chains} real HDDM chains saved", flush=True)


def main() -> None:
    parser = argparse.ArgumentParser(description="Real hierarchical HDDM fitting")
    parser.add_argument("action", choices=("check", "smoke", "run"))
    parser.add_argument("--study", choices=("study1", "study2", "both"), required=True)
    parser.add_argument("--model", choices=(*load_models(), "all"), required=True)
    parser.add_argument("--chains", type=int, default=4)
    parser.add_argument("--workers", type=int, default=4)
    # Provisional robust preset, NOT verified as Ting & Gluth (2025)'s settings.
    parser.add_argument("--samples", type=int, default=11000)
    parser.add_argument("--burn", type=int, default=5000)
    parser.add_argument("--seed", type=int, default=20260919)
    args = parser.parse_args()
    if args.action == "check":
        studies = ("study1", "study2") if args.study == "both" else (args.study,)
        names = load_models() if args.model == "all" else (args.model,)
        for study in studies:
            for name in names:
                _, audit = check_input(study, load_models()[name])
                print(f"PASS {study}/{name}: {audit['rows']} trials; "
                      f"rank {audit['design_rank']}/{audit['n_predictors']}", flush=True)
        return
    if args.study == "both" or args.model == "all":
        parser.error("smoke/run require one study and one model; use submit_fit.sh for all")
    if args.action == "smoke":
        run_fit(args.study, args.model, chains=1, workers=1,
                samples=min(args.samples, 250), burn=min(args.burn, 100),
                seed=args.seed, smoke=True)
    else:
        run_fit(args.study, args.model, chains=args.chains, workers=args.workers,
                samples=args.samples, burn=args.burn, seed=args.seed)


if __name__ == "__main__":
    main()
